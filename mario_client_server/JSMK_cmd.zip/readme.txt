Hello,

Whenever I try to run this program, there is a good chance that there will be a broken pipe error.
I am not really sure why that is, but I just thought to warn you.

Thank you.
