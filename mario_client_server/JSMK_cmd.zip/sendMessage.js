function sendMessage()
{

}
